<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');


$route['default_controller'] = "home";
$route['404_override'] = '';

$route['admin'] = 'admin/home';

/* End of file routes.php */
/* Location: ./application/config/routes.php */